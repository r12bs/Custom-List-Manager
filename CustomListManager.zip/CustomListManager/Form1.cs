﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;

using Microsoft.Win32;

namespace CustomListManager
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            this.Font = SystemFonts.MessageBoxFont;
            InitializeComponent();
        }

        ///////////////////////////////////////////////////////////////

        

        private string checkSBPR()
        {
            //checking for SBPR install, return null if not detected
            RegistryKey sbprKey = Registry.CurrentUser.OpenSubKey("Software\\illusion\\SexyBeachPR");
            if(sbprKey != null)
            {
                return sbprKey.GetValue("INSTALLDIR").ToString();
            }
            else
            {
                return null;
            }

        }

        ///////////////////////////////////////////////////////////////

        private string checkSB3U()
        {

            //here we check for SB3UGUI's path, return null if not found
            var sb3uPath = CustomListManager.Default.SB3UGPath;

            if (Directory.Exists(sb3uPath))
            {
                return sb3uPath;
            }
            else
            {
                return null;
            }            
        }

        ///////////////////////////////////////////////////////////////

        private string RemoveStuff(string FName)
        {
            //remove su/prefixes from filenames to create category list
            //this is crappy but feel free to fix it, I'm too lazy
            FName = FName.Replace("ca_f_", "(A) ");
            FName = FName.Replace("cf_f_", "(F) ");
            FName = FName.Replace("cf_m_", "(F) ");
            FName = FName.Replace("cf_t_", "(F) ");
            FName = FName.Replace("cm_f_", "(M) ");
            FName = FName.Replace("cm_m_", "(M) ");
            FName = FName.Replace("cm_t_", "(M) ");
            FName = FName.Replace("_CU", "");
            FName = FName.Replace("_b", " Back");
            FName = FName.Replace("_f", " Front");
            return FName;
        }

        ///////////////////////////////////////////////////////////////

        private List<string> extractCustomLists(string sb3uPath, string assetBundle)
        {

            //create script to list assets

            string tempDir = new DirectoryInfo("Temp").FullName;
            string scriptlistAssetsFileName = "Tools\\SB3UScripts\\listAssets.script";
            string[] scriptlistAssets = { "LoadPlugin(PluginDirectory + \"UnityPlugin.dll\")", "parser = OpenUnity3d(\"" + assetBundle + "\")", "editor = Unity3dEditor(parser, true)" };
            File.WriteAllLines(scriptlistAssetsFileName, scriptlistAssets);

            //Now I create a proccess for SB3U and get its output

            
        
            ProcessStartInfo p = new ProcessStartInfo();
            p.RedirectStandardOutput = true;
            p.UseShellExecute = false;
            p.FileName = sb3uPath + "\\SB3UtilityScript.exe";

            

            p.Arguments = new FileInfo(scriptlistAssetsFileName).FullName;
            p.CreateNoWindow = true;

            

            Process x = Process.Start(p);

            

            string[] list_output = x.StandardOutput.ReadToEnd().Replace('\r', '\n').Replace('\n', ' ').Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            List<string> extractLists = new List<string>();
            for (int i = 2; i < list_output.Length; i+=4)
            {
                if(!list_output[i].Contains("="))
                    extractLists.Add(list_output[i]);
            }

            x.WaitForExit();

            //var extractList = list_output[6];

            //create script for extracting
            List<string> finalList = new List<string>();
            string scriptexportAssetsFileName = "Tools\\SB3UScripts\\exportAssets.script";
            string scriptexportAssets = "LoadPlugin(PluginDirectory + \"UnityPlugin.dll\")\nparser = OpenUnity3d(\"" + assetBundle + "\")";
            foreach (string extractList in extractLists)
            { 
                
                scriptexportAssets +=  "\nExportTextAsset(parser, \"" + extractList + "\", \""+ tempDir +"\")" ;

                finalList.Add(tempDir + "\\" + extractList + ".textasset");
            }
            File.WriteAllText(scriptexportAssetsFileName, scriptexportAssets);

            p.Arguments = new FileInfo(scriptexportAssetsFileName).FullName;

            Process y = Process.Start(p);
            
            y.WaitForExit();
            /////////////////////          
            //finally return the list with the extracted files path

            return finalList;
        }

        ////////////////////////////////////////////

        private void Form1_Load(object sender, EventArgs e)
        {
            //check if SBPR is installed, assign result to a var
            var sbprInstall = checkSBPR();


            //if installed, activate checkbox that says it's detected and set a tooltip for it
            //with the install path
            if (sbprInstall != null)
            {
                checkBox2.Checked = true;
                toolTip1.SetToolTip(checkBox2, sbprInstall);
            }
            //else say it wasn't detected and close the application
            else
            {
                checkBox2.Checked = false;
                MessageBox.Show("Sexy Beach Premium Resort not detected in Registry, please check your installation", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Application.Exit();
            }

            //assign SB3UtilityScript's path to a var for easier future reference
            var sb3uPath = CustomListManager.Default.SB3UGPath + "\\SB3UtilityScript.exe";            

            //check if SB3U's path was set in options, if found check checkBox1
            //that says it was detected, also set the tooltip to reflect the path
            if (File.Exists(sb3uPath))
            {
                checkBox1.Checked = true;
                toolTip1.SetToolTip(checkBox1, CustomListManager.Default.SB3UGPath);
            }
            //else have it unchecked and set the tooltip to say you must set the path in Options
            else
            {
                checkBox1.Checked = false;
                toolTip1.SetToolTip(checkBox1, "Please set a valid path of SB3UtilityGUI in Options");
            }

            
            //create table for categories

            DataTable files_table = new DataTable();
            //first column that you can see
            files_table.Columns.Add("Type");
            //second column with file path
            files_table.Columns.Add("File");
            //third column with category for selection when installing
            files_table.Columns.Add("Category");
            //fourth column with columns templates for the right datagridview
            files_table.Columns.Add("Columns");
            //fifth column with the min limit
            files_table.Columns.Add("MinLimit");
            //fifth column with the min limit
            files_table.Columns.Add("MaxLimit");

            //get files from Custom directory
            var files = Directory.GetFiles("Custom");
            
            var template_files = Directory.GetFiles("Templates");

            var limits_file = File.ReadAllLines("Limits\\limits.txt");
            //MessageBox.Show("Pause");

            //put both previous arrays inside another array (going deeper)
            var filesandtemplates = files.Zip(template_files, (f, t) => new { File_F = f, File_T = t});



            //get category name and file name in the datatable for each file
            var rowindex = 0;

            foreach (var ft in filesandtemplates)
            {
                
                var row = files_table.NewRow();                

                row["Type"] = RemoveStuff(Path.GetFileNameWithoutExtension(ft.File_F));                
                row["File"] = ft.File_F;
                var hiddenCategory = new FileInfo(ft.File_F).Name;
                row["Category"] = hiddenCategory.Substring(0, hiddenCategory.Length - 13);
                //hiddenCategory.Substring(0, hiddenCategory.Length - 13)
                row["Columns"] = ft.File_T;
                row["MinLimit"] = limits_file[rowindex].Split('\t')[1];
                row["MaxLimit"] = limits_file[rowindex].Split('\t')[2];
                files_table.Rows.Add(row);
                rowindex += 1;           
            }                        

            
            

            //MessageBox.Show(files_table.Columns.Count.ToString());         

            //assign datatable to the form's gridview
            dataGridView1.DataSource = files_table;    
            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.Columns[1].Visible = true;    
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        //here we make it so every time you click on a category you get the data related to it
        //in the right gridview
        private void dataGridView1_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
                       
            if(dataGridView1.SelectedRows.Count > 0)
            {
                
                //get selected row's cell value
                string selected_file = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
                string selected_template = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();

                //if the selected value reflects a file that exists
                if (File.Exists(selected_file))
                { 
                    //get all lines from the file
                    var lines = File.ReadAllLines(selected_file);
                    var template_lines = File.ReadAllLines(selected_template);
                    //split the first line by tabs to get the amount of columns
                    var columns = template_lines[0].Split('\t').Length;
                    
                    //create new table for the contents of the file
                    DataTable file_contents_table = new DataTable();
                    
                    //create columns automatically, name them just a number
                    //this is ugly but feel free to change it, this
                    //was the fastest way I found of doing this
                    //use the amount of separated "words" to get the
                    //amount of columns with a loop
                    for (int i = 0; i < columns; i++)
                    {
                        file_contents_table.Columns.Add(i.ToString());
                    }

                    file_contents_table.Columns[0].DataType = System.Type.GetType("System.Int32");

                    //if there's actual content in the file
                    if (lines.Length > 0)
                    {
                        //actually get every line from the file
                        //separated by tabs, then insert this into the table
                        //made for the contents of the file
                        foreach(string line in lines)
                        {
                            var row = file_contents_table.NewRow();
                            var separated_line = line.Split('\t');

                            for(int i = 0; i < file_contents_table.Columns.Count; i++)
                            {
                                row[i] = separated_line[i];
                            }

                            file_contents_table.Rows.Add(row);

                            
                            
                        }

                        
                    }
                    ////else set the gridview's datasource to null to display nothing
                    //else
                    //{
                    //    dataGridView2.DataSource = null;
                    //}
                    //sort table by ID
                    file_contents_table.PrimaryKey = new DataColumn[] { file_contents_table.Columns[0] };
                    file_contents_table.DefaultView.Sort = "[0] ASC";

                    //assign table to gridview's datasource
                    dataGridView2.DataSource = file_contents_table;

                    dataGridView2.AutoGenerateColumns = true;
                }

                
            }

        }

        //function to open the options form
        private void button1_Click(object sender, EventArgs e)
        {
            Form2 optionsForm = new Form2(this);
            optionsForm.Show();
        }

        //function to check if SB3UGUI's path is set every time the form is redrawn (example: Refresh() called on the form)
        //used by options form when it calls refresh on this form
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            if (File.Exists(CustomListManager.Default.SB3UGPath + "\\SB3UtilityScript.exe"))
            {
                checkBox1.Checked = true;
            }
            else
            {
                checkBox1.Checked = false;
            }
        }


        //Process for archive extraction
        private int extractArchive(string file)
        {
            //create a new proccess start info
            ProcessStartInfo p = new ProcessStartInfo();
            //set 7zip's executable path to the proccess start info FileName
            p.FileName = "Tools\\7zip\\7za.exe";

            //set the arguments for the proccess, using the parameter file as the input
            p.Arguments = "x -oTemp -y \"" + file + "\"";

            //hide 7zip's window
            p.WindowStyle = ProcessWindowStyle.Hidden;

            //finally execute 7zip with the arguments given
            Process x = Process.Start(p);

            //wait until 7zip exits to continue program execution
            x.WaitForExit();
            
            //return 7zip's ExitCode, 0 is all is fine
            return x.ExitCode;
        }

        
        //function to open the archive and proccess it
        private void button2_Click(object sender, EventArgs e)
        {
            //having an openFileDialog in the form already, check for its result
            //if OK
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                //set the file name to new local variable fileName
                var fileName = openFileDialog1.FileName;
                //MessageBox.Show(fileName);

                //use the extractArchive function to extract the archive, if error code is 0
                if(extractArchive(fileName) == 0)
                {
                    //get Temp directory's info into tempDir
                    DirectoryInfo tempDir = new DirectoryInfo("Temp");

                    //check if the correct hierarchy for character files exists
                    bool checkCharaCustom = Directory.Exists("Temp\\abdata\\List\\CharaCustom");
                    bool checkChara = Directory.Exists("Temp\\abdata\\Chara");

                    //if both exist, and they both MUST exist
                    if (checkCharaCustom && checkChara)
                    {
                        //get all the files from the CustomList directory
                        var characustomlistFiles = Directory.GetFiles("Temp\\abdata\\List\\CharaCustom");

                        //check if there's files in the directory
                        if(characustomlistFiles.Length > 0)
                        {
                            //get sb3u's path with the checkSB3U function
                            string sb3uPath = checkSB3U();

                            //*I probably should check for the file's extension, I don't know how to check for its header yet so
                            //please refrain from copying strange files in the directory for now...*
                            //for each file in the customlist directory
                            foreach (string characustomlistFile in characustomlistFiles)
                            {
                                //set the full path of the file to a new local string
                                string _charaCustomFile = new FileInfo(characustomlistFile).FullName;
                                //MessageBox.Show(_charaCustomFile);

                                //use the extractCustomLists function to get the textassets from it
                                //assign resulting list to a new List
                                List<string> textAssets = extractCustomLists(sb3uPath, _charaCustomFile);

                                //create list for categories
                                //List<string> categories = new List<string>();
                                
                                //use the name of the textasset files to get categories
                                foreach(string textAsset in textAssets)
                                {
                                    //categories.Add(textAsset.Substring(0, textAsset.Length - 3));

                                    string file = new FileInfo(textAsset).Name;

                                    var category = file.Substring(0, (file.Length-13));

                                    foreach(DataGridViewRow d_row in dataGridView1.Rows)
                                    {
                                        if(d_row.Cells[2].Value.ToString().Equals(category))
                                        {
                                            d_row.Cells[2].Selected = true;

                                            var minLimit = Int32.Parse(d_row.Cells[4].Value.ToString());
                                            var maxLimit = Int32.Parse(d_row.Cells[5].Value.ToString());

                                            
                                            //var lastID = Int32.Parse(dataGridView2.CurrentCell.Value.ToString());
                                            
                                            //foreach (string line in File.ReadAllLines(textAsset))
                                            //{
                                            //    dataGridView2.Rows.Add(line.Split('\t'));
                                            //}
                                            DataTable dt = new DataTable();
                                            dt = (DataTable)dataGridView2.DataSource;

                                            foreach (string line in File.ReadAllLines(textAsset))
                                            {
                                                var linetoadd = line.Split('\t');
                                                
                                                if(Int32.Parse(linetoadd[0]) < minLimit )
                                                {
                                                    MessageBox.Show("It seems the ID for this is less than the minimum allowed, skipping");
                                                    continue;
                                                }

                                                if (Int32.Parse(linetoadd[0]) > maxLimit)
                                                {
                                                    MessageBox.Show("It seems the ID for this is more than the maximum allowed, skipping");
                                                    continue;
                                                }
                                            
                                                var searchID = dt.Rows.Find(linetoadd[0]);

                                                do
                                                {
                                                    linetoadd[0] = (Int32.Parse(linetoadd[0].ToString())+1).ToString();
                                                    searchID = dt.Rows.Find(linetoadd[0]);
                                                } while (searchID != null);

                                                
                                                dt.Rows.Add(linetoadd);

                                                FileInfo installedTXT = new FileInfo("Mods\\Installed.txt");

                                                StreamWriter streamToInstalled = installedTXT.AppendText();

                                                streamToInstalled.WriteLine(category + "\t" + (String.Join("\t", linetoadd)));

                                                streamToInstalled.Close();
                                            }

                                            dataGridView2.DataSource = dt;
                                            if (dataGridView2.Rows.Count > 0)
                                            {
                                                dataGridView2.CurrentCell = dataGridView2.Rows[dataGridView2.Rows.Count - 1].Cells[0];//dataGridView2.Rows[dataGridView2.Rows.Count-1].Cells[0].Selected = true;
                                            }

                                            StreamWriter sw = File.CreateText(d_row.Cells[1].Value.ToString());

                                            foreach (DataRow row in dt.Rows)
                                            {
                                                sw.WriteLine(String.Join("\t", row.ItemArray));
                                            }
                                            //sw.WriteLine("");                                            

                                            sw.Close();

                                            


                                            MessageBox.Show("Pause");
                                            //}
                                            //else
                                            //{
                                            //    var lastID = dataGridView1.CurrentRow.Cells[4].Value.ToString();
                                            //    
                                            //    DataTable dt = new DataTable();
                                            //    dt = (DataTable)dataGridView2.DataSource;
                                            //    foreach (string line in File.ReadAllLines(textAsset))
                                            //    {
                                            //        
                                            //        var linetoadd = line.Split('\t');
                                            //
                                            //        var searchID = dt.Rows.Find(linetoadd[0]);
                                            //
                                            //        
                                            //
                                            //        do{
                                            //            linetoadd[0] = linetoadd[0];
                                            //        }while(searchID != null);
                                            //
                                            //        dt.Rows.Add(linetoadd);
                                            //    }
                                            //    dataGridView2.DataSource = dt;
                                            //    MessageBox.Show(lastID);
                                            //}
                                            


                                        }
                                    }

                                }

                                
                            }

                            //show a confirmation box I guess
                            MessageBox.Show("Done!");

                            //procceed to delete all files in the temp directory
                            foreach (FileInfo file in tempDir.GetFiles())
                            {
                                file.Delete();
                            }
                            foreach (DirectoryInfo dir in tempDir.GetDirectories())
                            {
                                dir.Delete(true);
                            }
                        }
                        else
                        {
                            //if no files are found in the customlist directory, then show this box
                            MessageBox.Show("There are no files in this archive's CharaCustom directory");
                        }//<-- customlist directory amount of files check


                    }
                    //if the structure for character files is not right, show this box
                    else
                    {
                        MessageBox.Show("The directory structure of the file is not right");
                    }//<-- directory structure check

                }//<-- 7zip extraction check
                else
                {
                    //if 7zip's exit code is not 0, show this box
                    //I probably should work more on this, but right now I can't
                    MessageBox.Show("An error ocurred...");
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //debug only for now
            DataTable dt = new DataTable();
            dt = (DataTable)dataGridView2.DataSource;

            if(dataGridView2.SelectedCells[0].ColumnIndex == 0)
            { 
                DataRow search = dt.Rows.Find(Int32.Parse(dataGridView2.SelectedCells[0].Value.ToString()));

                if (search != null)
                {
                    MessageBox.Show("Found " + search["0"]);
                    search.Delete();

                    StreamWriter sw = File.CreateText(dataGridView1.SelectedRows[0].Cells[1].Value.ToString());

                    foreach (DataRow row in dt.Rows)
                    {
                        sw.WriteLine(String.Join("\t", row.ItemArray));
                    }
                    //sw.WriteLine("");

                    sw.Close();
                }
            }           
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form3 optionsForm = new Form3(this);
            optionsForm.Show();
        }
    }
}
