﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
using Microsoft.Win32;


namespace CustomListManager
{
    public partial class Form3 : Form
    {

        private string checkSB3U()
        {

            //here we check for SB3UGUI's path, return null if not found
            var sb3uPath = CustomListManager.Default.SB3UGPath;

            if (Directory.Exists(sb3uPath))
            {
                return sb3uPath;
            }
            else
            {
                return null;
            }
        }

        public Form parentForm;

        public Form3(Form parentForm)
        {
            InitializeComponent();
            this.parentForm = parentForm;
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            var sb3upath = checkSB3U();

            DataTable inst_table = new DataTable();

            var inst_file = File.ReadAllLines("Mods\\Installed.txt");            

            inst_table.Columns.Add("Filename");
            inst_table.Columns.Add("ID");
            inst_table.Columns.Add("Order");
            inst_table.Columns.Add("Name");
            inst_table.Columns.Add("File");


            inst_table.Columns[1].DataType = System.Type.GetType("System.Int32");

            if (inst_file.Length > 0)
            {
                
                foreach (string line in inst_file)
                {
                    
                    var row = inst_table.NewRow();
                    var separated_line = line.Split('\t');

                    
                    row["Filename"] = separated_line[0];
                    row["ID"] = separated_line[1];
                    row["Order"] = separated_line[2];
                    row["Name"] = separated_line[3];
                    row["File"] = separated_line[4];


                    inst_table.Rows.Add(row);
                }
                MessageBox.Show("test");
                inst_table.PrimaryKey = new DataColumn[] { inst_table.Columns[1] };

                inst_table.DefaultView.Sort = "[Filename] ASC";
                
                //assign table to gridview's datasource
                dataGridView1.DataSource = inst_table;
                
                dataGridView1.AutoGenerateColumns = true;
            }
        }
    }
}
